"use client"

import { useState } from "react"
import DesignerPanel from "./designer-panel"
import CoderPanel from "./coder-panel"

export default function SplitHero() {
  const [hoveredPanel, setHoveredPanel] = useState<"designer" | "coder" | null>(null)

  return (
    <div className="flex flex-col md:flex-row h-screen w-full">
      {/* Designer Panel */}
      <div
        className={`
          relative transition-all duration-500 ease-in-out
          ${hoveredPanel === "designer" ? "md:w-3/5" : hoveredPanel === "coder" ? "md:w-2/5" : "md:w-1/2"}
          ${hoveredPanel === "coder" ? "opacity-60" : "opacity-100"}
          h-1/2 md:h-full w-full
        `}
        onMouseEnter={() => setHoveredPanel("designer")}
        onMouseLeave={() => setHoveredPanel(null)}
      >
        <DesignerPanel />
      </div>

      {/* Coder Panel */}
      <div
        className={`
          relative transition-all duration-500 ease-in-out
          ${hoveredPanel === "coder" ? "md:w-3/5" : hoveredPanel === "designer" ? "md:w-2/5" : "md:w-1/2"}
          ${hoveredPanel === "designer" ? "opacity-60" : "opacity-100"}
          h-1/2 md:h-full w-full
        `}
        onMouseEnter={() => setHoveredPanel("coder")}
        onMouseLeave={() => setHoveredPanel(null)}
      >
        <CoderPanel />
      </div>
    </div>
  )
}
