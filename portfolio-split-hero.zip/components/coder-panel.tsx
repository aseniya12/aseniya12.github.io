"use client"

import { Code, Terminal, Zap } from "lucide-react"
import CodeAnimator from "./code-animator"
import SocialLinks from "./social-links"

export default function CoderPanel() {
  return (
    <div className="bg-black h-full flex flex-col justify-center items-center p-8 md:p-12 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 right-10">
          <Terminal className="w-24 h-24 text-green-400" />
        </div>
        <div className="absolute bottom-20 left-10">
          <Code className="w-16 h-16 text-blue-400" />
        </div>
        <div className="absolute top-1/3 left-1/4">
          <Zap className="w-12 h-12 text-yellow-400" />
        </div>
      </div>

      {/* Content */}
      <div className="text-center z-10 max-w-md">
        {/* Avatar */}
        <div className="mb-8">
          <div className="w-32 h-32 mx-auto rounded-full bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center border-4 border-gray-700">
            <Code className="w-16 h-16 text-green-400" />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">Coder</h1>

        {/* Subtitle */}
        <p className="text-lg md:text-xl text-gray-300 mb-2 font-medium">Full-Stack Developer</p>

        {/* Description */}
        <p className="text-gray-400 mb-8 leading-relaxed">
          I build scalable applications and bring designs to life with clean, efficient code and modern technologies.
        </p>

        {/* Code Animation */}
        <div className="mb-8">
          <CodeAnimator />
        </div>

        {/* Social Links */}
        <SocialLinks theme="dark" />
      </div>
    </div>
  )
}
