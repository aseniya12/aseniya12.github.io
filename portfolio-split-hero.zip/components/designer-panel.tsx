"use client"

import { Download, Palette, Lightbulb, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import SocialLinks from "./social-links"

export default function DesignerPanel() {
  return (
    <div className="bg-white h-full flex flex-col justify-center items-center p-8 md:p-12 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 left-10">
          <Palette className="w-24 h-24 text-gray-400" />
        </div>
        <div className="absolute bottom-20 right-10">
          <Lightbulb className="w-16 h-16 text-gray-400" />
        </div>
        <div className="absolute top-1/3 right-1/4">
          <Sparkles className="w-12 h-12 text-gray-400" />
        </div>
      </div>

      {/* Content */}
      <div className="text-center z-10 max-w-md">
        {/* Avatar */}
        <div className="mb-8">
          <div className="w-32 h-32 mx-auto rounded-full bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center border-4 border-gray-300">
            <Palette className="w-16 h-16 text-gray-600" />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-4">Designer</h1>

        {/* Subtitle */}
        <p className="text-lg md:text-xl text-gray-600 mb-2 font-medium">Creative Problem Solver</p>

        {/* Description */}
        <p className="text-gray-500 mb-8 leading-relaxed">
          I craft beautiful, intuitive experiences that delight users and solve real problems through thoughtful design.
        </p>

        {/* Download Resume Button */}
        <Button
          variant="outline"
          size="lg"
          className="mb-8 border-2 border-gray-900 text-gray-900 hover:bg-gray-900 hover:text-white transition-all duration-300 font-semibold px-8 bg-transparent"
        >
          <Download className="w-4 h-4 mr-2" />
          Download Resume
        </Button>

        {/* Social Links */}
        <SocialLinks theme="light" />
      </div>
    </div>
  )
}
