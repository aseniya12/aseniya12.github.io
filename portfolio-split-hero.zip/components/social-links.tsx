"use client"

import { Github, Linkedin, Twitter, Dribbble, ExternalLink } from "lucide-react"

interface SocialLinksProps {
  theme: "light" | "dark"
}

export default function SocialLinks({ theme }: SocialLinksProps) {
  const iconClass = theme === "light" ? "text-gray-600 hover:text-gray-900" : "text-gray-400 hover:text-white"

  const socialLinks = [
    { icon: Github, href: "#", label: "GitHub" },
    { icon: Linkedin, href: "#", label: "LinkedIn" },
    { icon: Twitter, href: "#", label: "Twitter" },
    { icon: Dribbble, href: "#", label: "Dribbble" },
    { icon: ExternalLink, href: "#", label: "Portfolio" },
  ]

  return (
    <div className="flex justify-center space-x-6">
      {socialLinks.map(({ icon: Icon, href, label }) => (
        <a
          key={label}
          href={href}
          className={`${iconClass} transition-all duration-300 hover:scale-110 transform`}
          aria-label={label}
        >
          <Icon className="w-6 h-6" />
        </a>
      ))}
    </div>
  )
}
