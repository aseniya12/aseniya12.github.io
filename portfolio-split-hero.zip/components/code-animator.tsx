"use client"

import { useState, useEffect } from "react"

const codeSnippets = [
  `const portfolio = {
  designer: true,
  developer: true,
  passion: "creating"
}`,
  `function buildAmazingThings() {
  return design + code + ❤️
}`,
  `<Component>
  <Design />
  <Code />
  <Innovation />
</Component>`,
]

export default function CodeAnimator() {
  const [currentSnippet, setCurrentSnippet] = useState(0)
  const [displayedText, setDisplayedText] = useState("")
  const [isTyping, setIsTyping] = useState(true)

  useEffect(() => {
    const snippet = codeSnippets[currentSnippet]
    let index = 0

    const typeInterval = setInterval(() => {
      if (index < snippet.length) {
        setDisplayedText(snippet.slice(0, index + 1))
        index++
      } else {
        setIsTyping(false)
        clearInterval(typeInterval)

        // Wait before starting next snippet
        setTimeout(() => {
          setIsTyping(true)
          setDisplayedText("")
          setCurrentSnippet((prev) => (prev + 1) % codeSnippets.length)
        }, 2000)
      }
    }, 50)

    return () => clearInterval(typeInterval)
  }, [currentSnippet])

  return (
    <div className="bg-gray-900 rounded-lg p-4 text-left font-mono text-sm border border-gray-700">
      <div className="flex items-center mb-2">
        <div className="flex space-x-1">
          <div className="w-3 h-3 rounded-full bg-red-500"></div>
          <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
          <div className="w-3 h-3 rounded-full bg-green-500"></div>
        </div>
      </div>
      <pre className="text-green-400 min-h-[80px]">
        <code>
          {displayedText}
          {isTyping && <span className="animate-pulse">|</span>}
        </code>
      </pre>
    </div>
  )
}
