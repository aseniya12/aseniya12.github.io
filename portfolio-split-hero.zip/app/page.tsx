import SplitHero from "@/components/split-hero"

export default function Home() {
  return (
    <main className="min-h-screen">
      <SplitHero />
    </main>
  )
}
